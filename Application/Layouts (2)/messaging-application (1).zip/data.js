export let CategoryEnum = /*#__PURE__*/ (function (CategoryEnum) {
  CategoryEnum["APPLICATION"] = "application";
  CategoryEnum["AI"] = "ai";
  CategoryEnum["MARKETING"] = "marketing";
  CategoryEnum["ECOMMERCE"] = "ecommerce";

  return CategoryEnum;
})({});
